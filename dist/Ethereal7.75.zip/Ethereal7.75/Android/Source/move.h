/*
  Ethereal is a UCI chess playing engine authored by Andrew Grant.
  <https://github.com/AndyGrant/Ethereal>     <andrew@grantnet.us>
  
  Ethereal is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  Ethereal is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __MOVE_H
#define __MOVE_H

#include <stdint.h>

#include "types.h"

void applyMove(Board * board, uint16_t move, Undo * undo);
void revertMove(Board * board, uint16_t move, Undo * undo);
void printMove(uint16_t move);

#define NoneMove ( 0)
#define NullMove (11)

#define NormalMove      (0 << 12)
#define CastleMove      (1 << 12)
#define EnpassMove      (2 << 12)
#define PromotionMove   (3 << 12)

#define PromoteToKnight (0 << 14)
#define PromoteToBishop (1 << 14)
#define PromoteToRook   (2 << 14)
#define PromoteToQueen  (3 << 14)

#define MoveFrom(move)         (((move) >> 0) & 63)
#define MoveTo(move)           (((move) >> 6) & 63)
#define MoveType(move)         ((move) & (3 << 12))
#define MovePromoType(move)    ((move) & (3 << 14))
#define MoveMake(from,to,flag) ((from) | ((to) << 6) | (flag))

#endif