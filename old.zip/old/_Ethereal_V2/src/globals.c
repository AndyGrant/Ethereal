#include "types.h"

board_t board;
search_tree_t tree;
zorbist_t zorbist;
ttable_t table;
evaltable_t evaltable;