#ifndef BOARD_H
#define BOARD_H

#include "types.h"

/* Function Protoypes */
void init_board_t(char setup[73]);
void encode_board_t(char str[73]);

#endif