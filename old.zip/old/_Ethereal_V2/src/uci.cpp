#include <iostream>
#include <string>
#include <vector>
#include <cassert>
#include <stdio.h>

extern "C" {	
	#include "types.h"
	#include "board.h"
	#include "colour.h"
	#include "move.h"
	#include "piece.h"
	#include "search.h"
	#include "util.h"
};

#include "uci.h"

extern board_t board;

char starting_position[73] = "rnbqkbnrppppppppeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeePPPPPPPPRNBQKBNR11110000";

char * decode_fen(char enc[73], std::string fen){
	int enci = 0;
	
	int i;
	for(i = 0;; i++){
		std::string str; str += fen[i];
		
		if (contains("12345678",str))
			for(int j = 0; j < fen[i] - '0'; j++)
				enc[enci++] = 'e';
		
		if (contains("pPnNbBrRqQkK",str))
			enc[enci++] = fen[i];
		
		if (fen[i] == ' ')
			break;
	}
	
	i++;
	enc[71] = fen[i] == 'w' ? '0' : '1';
	i += 2;
	
	enc[64] = '0';
	enc[65] = '0';
	enc[66] = '0';
	enc[67] = '0';
	
	for(;fen[i] != ' ';i++){
		if 		(fen[i] == 'K') enc[64] = '1';
		else if (fen[i] == 'Q') enc[65] = '1';
		else if (fen[i] == 'k') enc[66] = '1';
		else if (fen[i] == 'q') enc[67] = '1';
	}
	
	enc[68] = '0';
	enc[69] = '0';
	enc[70] = '0';
	enc[72] = '\0';
	return enc;
}

std::string convert_move_to_string(move_t move){
	std::string str;
	int from = MOVE_GET_FROM(move);
	int to = MOVE_GET_TO(move);
	
	str += ('a' - 4 + (from%16));
	str += ('8' + 4 - (from/16));
	str += ('a' - 4 + (to%16));
	str += ('8' + 4 - (to/16));
	
	if (MOVE_IS_PROMOTION(move))
		str += piece_to_char(MOVE_GET_PROMOTE_TYPE(move,1));
	
	return str;
}

void print_move_standard_notation(move_t move){
	std::string str = convert_move_to_string(move);
	std::cout << str;
}

void make_move_from_string(std::string move){
	int size = 0;
	move_t moves[MaxMoves];
	gen_all_legal_moves(&(moves[0]),&size);
	
	for(size -= 1; size >= 0; size--){
		if (move == convert_move_to_string(moves[size])){
			apply_move(moves[size]);
			return;
		}
	}
}

bool contains(std::string a, std::string b){
	return (a.find(b) != std::string::npos);
}

std::vector<std::string> parse_moves(std::string line){
	unsigned int start = line.find("moves")+6;
	std::vector<std::string> moves;
	std::string buff = "";
	char c;
	
	if (start -1 >= line.length())
		return moves;
	
	while(true){
		c = line[start++];
		
		if (c == ' '){
			moves.push_back(buff);
			buff = "";
		}
		else {
			buff += c;
		}
		
		if (start >= line.length()){
			moves.push_back(buff);
			break;
		}
	}
	
	return moves;
}

int main(){	
	std::string line;
	while(getline(std::cin,line)){
		
		if (line == "uci"){
			std::cout << "id name Ethereal\n";
			std::cout << "id author Andrew Grant\n";
			std::cout << "uciok\n";
		}

		if (contains(line,"debug")){

		}

		if (line == "isready"){
			std::cout << "readyok\n";
		}

		if (contains(line,"setoption")){

		}

		if (line == "register"){
			std::cout << "register later";
		}

		if (line == "ucinewgame"){

		}

		if (contains(line,"position")){		
			if (contains(line,"startpos"))
				init_board_t(starting_position);
			
			if (contains(line,"fen")){
				char encoding[73];
				decode_fen(&(encoding[0]),line.substr(line.find("fen")+4,std::string::npos));
				init_board_t(&(encoding[0]));
			}
			
			std::vector<std::string> moves = parse_moves(line);
			for(unsigned int i = 0; i < moves.size(); i++){
				make_move_from_string(moves[i]);
				board.ep_history[0] = board.ep_history[board.depth];
				board.depth = 0;
			}
		}

		if (contains(line,"go")){
			std::cout << "bestmove " << convert_move_to_string(get_best_move(1000)) << "\n";
		}

		if (line == "quit")
			break;
	}	
}