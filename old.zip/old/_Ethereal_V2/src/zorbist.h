#ifndef ZORBIST_H
#define ZORBIST_H

void init_zorbist_t();
int gen_bitstring();
void init_zorbist_hash();

#endif